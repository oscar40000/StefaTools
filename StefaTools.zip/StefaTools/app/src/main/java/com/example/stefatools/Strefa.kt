package com.example.stefatools

data class Strefa(
    var numer: Int,
    var nazwa: String,
    var dlugosc: String,
    var opis: String
)