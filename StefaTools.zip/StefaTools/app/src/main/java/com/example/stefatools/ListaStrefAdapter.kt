package com.example.stefatools
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ListaStrefAdapter(
    private val ListaStref: MutableList<Strefa>
    ) : RecyclerView.Adapter<ListaStrefAdapter.ListaStrefViewHolder>() {

    inner class ListaStrefViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListaStrefViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.strefa_wiersz, parent, false)
        return ListaStrefViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListaStrefViewHolder, position: Int) {
        holder.

    }

    override fun getItemCount(): Int {
        return ListaStref.size
    }
}